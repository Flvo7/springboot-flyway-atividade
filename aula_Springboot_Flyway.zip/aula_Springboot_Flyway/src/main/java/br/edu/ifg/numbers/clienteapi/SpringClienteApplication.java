package br.edu.ifg.numbers.clienteapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringClienteApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringClienteApplication.class, args);
    }
}
